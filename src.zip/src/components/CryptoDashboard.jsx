import React, { useState, useEffect } from 'react';
import { Moon, Sun, Search, ArrowUpDown, RefreshCw } from 'lucide-react';
import CryptoConverter from './CryptoConverter';

const CryptoDashboard = () => {
  const [cryptoData, setCryptoData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: 'market_cap_rank', direction: 'asc' });
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [displayCount, setDisplayCount] = useState(10);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('prices'); // New state for tab management
  
  // Fetch cryptocurrency data from CoinGecko API
  const fetchCryptoData = async () => {
    try {
      setIsRefreshing(true);
      const response = await fetch(
        'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h'
      );
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();
      setCryptoData(data);
      setFilteredData(data);
      setIsLoading(false);
      setIsRefreshing(false);
    } catch (error) {
      setError('Failed to fetch data. CoinGecko API may have rate limiting in effect.');
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchCryptoData();
    
    // Set dark mode based on user preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setIsDarkMode(true);
    }
  }, []);
  
  // Apply dark mode class to body
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Filter cryptocurrencies based on search input
  useEffect(() => {
    const filtered = cryptoData.filter((crypto) =>
      crypto.name.toLowerCase().includes(search.toLowerCase()) ||
      crypto.symbol.toLowerCase().includes(search.toLowerCase())
    );
    setFilteredData(filtered);
  }, [search, cryptoData]);
  
  // Handle sort functionality
  const handleSort = (key) => {
    let direction = 'asc';
    
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    
    setSortConfig({ key, direction });
    
    const sortedData = [...filteredData].sort((a, b) => {
      if (a[key] < b[key]) {
        return direction === 'asc' ? -1 : 1;
      }
      if (a[key] > b[key]) {
        return direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
    
    setFilteredData(sortedData);
  };
  
  // Format large numbers with commas
  const formatNumber = (num) => {
    return num.toLocaleString();
  };
  
  // Format currency
  const formatCurrency = (num) => {
    if (num >= 1000000000) {
      return `$${(num / 1000000000).toFixed(2)}B`;
    } else if (num >= 1000000) {
      return `$${(num / 1000000).toFixed(2)}M`;
    } else if (num >= 1000) {
      return `$${(num / 1000).toFixed(2)}K`;
    } else {
      return `$${num.toFixed(2)}`;
    }
  };
  
  // Format price based on value
  const formatPrice = (price) => {
    if (price >= 1000) {
      return `$${formatNumber(Math.round(price))}`;
    } else if (price >= 1) {
      return `$${price.toFixed(2)}`;
    } else {
      return `$${price.toFixed(6)}`;
    }
  };
  
  // Toggle dark/light mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  // Handle display count change
  const handleDisplayCountChange = (e) => {
    setDisplayCount(Number(e.target.value));
  };
  
  // Manual refresh function
  const handleRefresh = () => {
    fetchCryptoData();
  };
  
  // Tab change handler
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-blue-500 border-t-transparent mx-auto"></div>
          <p className="text-lg text-gray-700 dark:text-gray-300">Loading cryptocurrency data...</p>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="rounded-lg bg-white p-8 shadow-lg dark:bg-gray-800">
          <h2 className="mb-4 text-xl font-bold text-red-500">Error</h2>
          <p className="text-gray-700 dark:text-gray-300">{error}</p>
          <button 
            className="mt-4 rounded-md bg-blue-500 px-4 py-2 text-white hover:bg-blue-600"
            onClick={handleRefresh}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`min-h-screen bg-gray-100 transition-colors duration-300 dark:bg-gray-900`}>
      <header className="bg-white shadow-md dark:bg-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                Crypto Price Tracker
              </h1>
              <button 
                onClick={toggleDarkMode}
                className="ml-4 rounded-full p-2 text-gray-500 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-700"
                aria-label="Toggle dark mode"
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>
            </div>
            
            <div className="mt-4 flex items-center md:mt-0">
              <div className="relative">
                <Search 
                  className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" 
                />
                <input
                  type="text"
                  placeholder="Search cryptocurrencies..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full rounded-md border border-gray-300 bg-white py-2 pl-10 pr-4 text-gray-700 focus:border-blue-500 focus:outline-none dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 md:w-64"
                />
              </div>
              
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className={`ml-2 flex items-center rounded-md bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 ${isRefreshing ? 'opacity-75' : ''}`}
              >
                <RefreshCw size={16} className={`mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="mt-6 border-b border-gray-200 dark:border-gray-700">
            <nav className="-mb-px flex space-x-6">
              <button
                onClick={() => handleTabChange('prices')}
                className={`pb-3 px-1 ${
                  activeTab === 'prices'
                    ? 'border-b-2 border-blue-500 font-medium text-blue-600 dark:text-blue-400'
                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                Price Tracker
              </button>
              <button
                onClick={() => handleTabChange('converter')}
                className={`pb-3 px-1 ${
                  activeTab === 'converter'
                    ? 'border-b-2 border-blue-500 font-medium text-blue-600 dark:text-blue-400'
                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                Currency Converter
              </button>
            </nav>
          </div>
          
          {activeTab === 'prices' && (
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Showing {Math.min(displayCount, filteredData.length)} of {filteredData.length} cryptocurrencies
              </p>
              
              <div className="mt-2 flex items-center sm:mt-0">
                <label htmlFor="displayCount" className="mr-2 text-sm text-gray-600 dark:text-gray-400">
                  Display:
                </label>
                <select
                  id="displayCount"
                  value={displayCount}
                  onChange={handleDisplayCountChange}
                  className="rounded-md border border-gray-300 bg-white px-2 py-1 text-sm text-gray-700 focus:border-blue-500 focus:outline-none dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>
          )}
        </div>
      </header>
      
      <main className="container mx-auto p-4">
        {activeTab === 'prices' ? (
          <div className="overflow-x-auto rounded-lg bg-white shadow-md dark:bg-gray-800">
            <table className="w-full table-auto">
              <thead>
                <tr className="bg-gray-50 text-left text-xs font-semibold uppercase tracking-wider text-gray-700 dark:bg-gray-700 dark:text-gray-300">
                  <th className="px-4 py-3">
                    <button 
                      className="flex items-center"
                      onClick={() => handleSort('market_cap_rank')}
                    >
                      # 
                      <ArrowUpDown size={14} className="ml-1" />
                    </button>
                  </th>
                  <th className="px-4 py-3">Coin</th>
                  <th className="px-4 py-3">
                    <button 
                      className="flex items-center"
                      onClick={() => handleSort('current_price')}
                    >
                      Price
                      <ArrowUpDown size={14} className="ml-1" />
                    </button>
                  </th>
                  <th className="px-4 py-3">
                    <button 
                      className="flex items-center"
                      onClick={() => handleSort('price_change_percentage_24h')}
                    >
                      24h %
                      <ArrowUpDown size={14} className="ml-1" />
                    </button>
                  </th>
                  <th className="px-4 py-3">
                    <button 
                      className="flex items-center"
                      onClick={() => handleSort('market_cap')}
                    >
                      Market Cap
                      <ArrowUpDown size={14} className="ml-1" />
                    </button>
                  </th>
                  <th className="px-4 py-3">
                    <button 
                      className="flex items-center"
                      onClick={() => handleSort('total_volume')}
                    >
                      Volume (24h)
                      <ArrowUpDown size={14} className="ml-1" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {filteredData.slice(0, displayCount).map((crypto) => (
                  <tr 
                    key={crypto.id} 
                    className="hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    <td className="whitespace-nowrap px-4 py-4 text-sm text-gray-700 dark:text-gray-300">
                      {crypto.market_cap_rank}
                    </td>
                    <td className="whitespace-nowrap px-4 py-4">
                      <div className="flex items-center">
                        <div className="h-8 w-8 flex-shrink-0">
                          <img 
                            src={crypto.image} 
                            alt={crypto.name} 
                            className="h-8 w-8 rounded-full"
                          />
                        </div>
                        <div className="ml-3">
                          <p className="font-medium text-gray-900 dark:text-gray-100">
                            {crypto.name}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">
                            {crypto.symbol}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="whitespace-nowrap px-4 py-4 text-sm text-gray-700 dark:text-gray-300">
                      {formatPrice(crypto.current_price)}
                    </td>
                    <td className={`whitespace-nowrap px-4 py-4 text-sm ${
                      crypto.price_change_percentage_24h > 0 
                        ? 'text-green-600 dark:text-green-400' 
                        : 'text-red-600 dark:text-red-400'
                    }`}>
                      {crypto.price_change_percentage_24h > 0 ? '+' : ''}
                      {crypto.price_change_percentage_24h.toFixed(2)}%
                    </td>
                    <td className="whitespace-nowrap px-4 py-4 text-sm text-gray-700 dark:text-gray-300">
                      {formatCurrency(crypto.market_cap)}
                    </td>
                    <td className="whitespace-nowrap px-4 py-4 text-sm text-gray-700 dark:text-gray-300">
                      {formatCurrency(crypto.total_volume)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <CryptoConverter cryptoData={cryptoData} />
        )}
      </main>
      
      <footer className="bg-white py-4 text-center text-sm text-gray-600 shadow-md dark:bg-gray-800 dark:text-gray-400">
        <p>Data provided by CoinGecko API</p>
      </footer>
    </div>
  );
};

export default CryptoDashboard;