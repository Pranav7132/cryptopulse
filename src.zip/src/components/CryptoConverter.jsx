import React, { useState, useEffect } from 'react';
import { ArrowRight, RefreshCw } from 'lucide-react';

const CryptoConverter = () => {
  const [amount, setAmount] = useState('');
  const [fromCrypto, setFromCrypto] = useState('');
  const [toCurrency, setToCurrency] = useState('usd');
  const [result, setResult] = useState(null);
  const [cryptoData, setCryptoData] = useState([]);
  const [conversionRates, setConversionRates] = useState({});
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  
  // Top 10 cryptocurrencies to fetch
  const cryptoIds = [
    'bitcoin',
    'ethereum', 
    'tether',
    'solana',
    'binancecoin',
    'usd-coin',
    'ripple',
    'cardano',
    'dogecoin',
    'avalanche-2'
  ];

  const currencies = [
    { code: 'usd', name: 'US Dollar', symbol: '$' },
    { code: 'eur', name: 'Euro', symbol: '€' },
    { code: 'gbp', name: 'British Pound', symbol: '£' },
    { code: 'jpy', name: 'Japanese Yen', symbol: '¥' },
    { code: 'aud', name: 'Australian Dollar', symbol: 'A$' },
    { code: 'cad', name: 'Canadian Dollar', symbol: 'C$' },
    { code: 'chf', name: 'Swiss Franc', symbol: 'CHF' },
    { code: 'cny', name: 'Chinese Yuan', symbol: '¥' },
    { code: 'inr', name: 'Indian Rupee', symbol: '₹' },
    { code: 'krw', name: 'South Korean Won', symbol: '₩' },
  ];

  // Fetch real-time currency conversion rates
  const fetchCurrencyRates = async () => {
    try {
      const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
      if (response.ok) {
        const data = await response.json();
        setConversionRates({
          usd: 1,
          eur: 1 / data.rates.EUR,
          gbp: 1 / data.rates.GBP,
          jpy: 1 / data.rates.JPY,
          aud: 1 / data.rates.AUD,
          cad: 1 / data.rates.CAD,
          chf: 1 / data.rates.CHF,
          cny: 1 / data.rates.CNY,
          inr: 1 / data.rates.INR,
          krw: 1 / data.rates.KRW,
        });
      } else {
        // Fallback rates if API fails
        setConversionRates({
          usd: 1,
          eur: 0.92,
          gbp: 0.78,
          jpy: 153.2,
          aud: 1.54,
          cad: 1.37,
          chf: 0.90,
          cny: 7.24,
          inr: 83.52,
          krw: 1373.12,
        });
      }
    } catch (error) {
      console.error('Error fetching currency rates:', error);
      // Fallback rates
      setConversionRates({
        usd: 1,
        eur: 0.92,
        gbp: 0.78,
        jpy: 153.2,
        aud: 1.54,
        cad: 1.37,
        chf: 0.90,
        cny: 7.24,
        inr: 83.52,
        krw: 1373.12,
      });
    }
  };

  // Fetch real-time crypto data
  const fetchCryptoData = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://api.coingecko.com/api/v3/simple/price?ids=${cryptoIds.join(',')}&vs_currencies=usd&include_24hr_change=true`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch crypto data');
      }
      
      const data = await response.json();
      
      // Crypto info mapping
      const cryptoInfo = {
        bitcoin: { name: 'Bitcoin', symbol: 'btc' },
        ethereum: { name: 'Ethereum', symbol: 'eth' },
        tether: { name: 'Tether', symbol: 'usdt' },
        solana: { name: 'Solana', symbol: 'sol' },
        binancecoin: { name: 'BNB', symbol: 'bnb' },
        'usd-coin': { name: 'USD Coin', symbol: 'usdc' },
        ripple: { name: 'XRP', symbol: 'xrp' },
        cardano: { name: 'Cardano', symbol: 'ada' },
        dogecoin: { name: 'Dogecoin', symbol: 'doge' },
        'avalanche-2': { name: 'Avalanche', symbol: 'avax' }
      };
      
      // Transform data to match our expected format
      const transformedData = cryptoIds.map(id => ({
        id,
        name: cryptoInfo[id].name,
        symbol: cryptoInfo[id].symbol,
        current_price: data[id]?.usd || 0,
        price_change_24h: data[id]?.usd_24h_change || 0
      })).filter(crypto => crypto.current_price > 0); // Only include cryptos with valid prices
      
      setCryptoData(transformedData);
      setLastUpdated(new Date());
      
      // Set initial crypto if not set
      if (!fromCrypto && transformedData.length > 0) {
        setFromCrypto(transformedData[0].id);
      }
      
    } catch (error) {
      console.error('Error fetching crypto data:', error);
      // Fallback to comprehensive sample data if API fails
      const fallbackData = [
        { id: 'bitcoin', name: 'Bitcoin', symbol: 'btc', current_price: 67000, price_change_24h: 2.5 },
        { id: 'ethereum', name: 'Ethereum', symbol: 'eth', current_price: 3500, price_change_24h: 1.8 },
        { id: 'tether', name: 'Tether', symbol: 'usdt', current_price: 1.00, price_change_24h: 0.1 },
        { id: 'solana', name: 'Solana', symbol: 'sol', current_price: 165, price_change_24h: 4.2 },
        { id: 'binancecoin', name: 'BNB', symbol: 'bnb', current_price: 590, price_change_24h: -1.5 },
        { id: 'usd-coin', name: 'USD Coin', symbol: 'usdc', current_price: 1.00, price_change_24h: 0.0 },
        { id: 'ripple', name: 'XRP', symbol: 'xrp', current_price: 0.55, price_change_24h: 3.8 },
        { id: 'cardano', name: 'Cardano', symbol: 'ada', current_price: 0.48, price_change_24h: -2.1 },
        { id: 'dogecoin', name: 'Dogecoin', symbol: 'doge', current_price: 0.13, price_change_24h: 5.6 },
        { id: 'avalanche-2', name: 'Avalanche', symbol: 'avax', current_price: 38.50, price_change_24h: 1.9 }
      ];
      setCryptoData(fallbackData);
      if (!fromCrypto) setFromCrypto('bitcoin');
    } finally {
      setLoading(false);
    }
  };

  // Fetch both crypto and currency data
  const fetchAllData = async () => {
    await Promise.all([
      fetchCryptoData(),
      fetchCurrencyRates()
    ]);
  };

  // Fetch data on component mount
  useEffect(() => {
    fetchAllData();
    
    // Set up auto-refresh every 30 seconds
    const interval = setInterval(fetchAllData, 30000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Clear result when inputs change
  const handleAmountChange = (value) => {
    setAmount(value);
    setResult(null);
  };
  
  const handleFromCryptoChange = (value) => {
    setFromCrypto(value);
    setResult(null);
  };
  
  const handleToCurrencyChange = (value) => {
    setToCurrency(value);
    setResult(null);
  };

  const handleConvert = () => {
    const selectedCrypto = cryptoData.find(crypto => crypto.id === fromCrypto);
    const numericAmount = parseFloat(amount) || 0;
    
    if (selectedCrypto && numericAmount > 0 && conversionRates[toCurrency]) {
      // First convert to USD
      const amountInUsd = numericAmount * selectedCrypto.current_price;
      
      // Then convert to target currency
      const finalAmount = amountInUsd * (conversionRates[toCurrency] || 1);
      
      setResult({
        fromAmount: numericAmount,
        fromCrypto: selectedCrypto.name,
        fromSymbol: selectedCrypto.symbol.toUpperCase(),
        toAmount: finalAmount,
        toCurrency: toCurrency.toUpperCase(),
        currencySymbol: currencies.find(c => c.code === toCurrency)?.symbol || '$'
      });
    }
  };

  // Format number with appropriate decimal places
  const formatNumber = (num) => {
    if (num >= 1000) return num.toLocaleString(undefined, { maximumFractionDigits: 2 });
    if (num >= 1) return num.toLocaleString(undefined, { maximumFractionDigits: 6 });
    return num.toLocaleString(undefined, { maximumFractionDigits: 8 });
  };

  // Format price change
  const formatPriceChange = (change) => {
    const isPositive = change >= 0;
    return (
      <span className={`text-sm ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
        {isPositive ? '+' : ''}{change.toFixed(2)}%
      </span>
    );
  };

  if (loading && cryptoData.length === 0) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md dark:bg-gray-800">
        <div className="flex items-center justify-center py-8">
          <RefreshCw className="animate-spin mr-2" size={20} />
          <span className="text-gray-600 dark:text-gray-300">Loading crypto data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md dark:bg-gray-800">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">Crypto Converter</h2>
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
          <button
            onClick={fetchAllData}
            className="flex items-center hover:text-blue-500 transition-colors"
            disabled={loading}
          >
            <RefreshCw className={`mr-1 ${loading ? 'animate-spin' : ''}`} size={16} />
            Refresh
          </button>
          {lastUpdated && (
            <span className="ml-2">
              Updated: {lastUpdated.toLocaleTimeString()}
            </span>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Amount
          </label>
          <input
            id="amount"
            type="number"
            min="0"
            step="any"
            value={amount}
            onChange={(e) => handleAmountChange(e.target.value)}
            placeholder="Enter amount"
            className="w-full rounded-md border border-gray-300 bg-white py-2 px-3 text-gray-700 focus:border-blue-500 focus:outline-none dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
          />
        </div>
        
        <div>
          <label htmlFor="fromCrypto" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            From (Crypto)
          </label>
          <select
            id="fromCrypto"
            value={fromCrypto}
            onChange={(e) => handleFromCryptoChange(e.target.value)}
            className="w-full rounded-md border border-gray-300 bg-white py-2 px-3 text-gray-700 focus:border-blue-500 focus:outline-none dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
          >
            {cryptoData.map((crypto) => (
              <option key={crypto.id} value={crypto.id}>
                {crypto.name} ({crypto.symbol.toUpperCase()}) - ${formatNumber(crypto.current_price)}
              </option>
            ))}
          </select>
          {fromCrypto && cryptoData.find(c => c.id === fromCrypto) && (
            <div className="mt-1 flex items-center justify-between text-xs">
              <span className="text-gray-500 dark:text-gray-400">
                ${formatNumber(cryptoData.find(c => c.id === fromCrypto).current_price)}
              </span>
              {formatPriceChange(cryptoData.find(c => c.id === fromCrypto).price_change_24h)}
            </div>
          )}
        </div>
        
        <div>
          <label htmlFor="toCurrency" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            To (Fiat Currency)
          </label>
          <select
            id="toCurrency"
            value={toCurrency}
            onChange={(e) => handleToCurrencyChange(e.target.value)}
            className="w-full rounded-md border border-gray-300 bg-white py-2 px-3 text-gray-700 focus:border-blue-500 focus:outline-none dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
          >
            {currencies.map((currency) => (
              <option key={currency.code} value={currency.code}>
                {currency.name} ({currency.symbol})
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="flex justify-center mb-6">
        <button
          onClick={handleConvert}
          className="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 disabled:opacity-50"
          disabled={loading}
        >
          Convert
        </button>
      </div>
      
      {result && (
        <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
          <div className="flex items-center justify-center text-lg">
            <div className="font-medium text-gray-800 dark:text-gray-200">
              {formatNumber(result.fromAmount)} {result.fromSymbol}
            </div>
            <ArrowRight className="mx-4 text-gray-500" size={20} />
            <div className="font-medium text-gray-800 dark:text-gray-200">
              {result.currencySymbol}{formatNumber(result.toAmount)}
            </div>
          </div>
          <p className="text-center mt-2 text-sm text-gray-600 dark:text-gray-400">
            1 {result.fromSymbol} = {result.currencySymbol}{formatNumber(cryptoData.find(c => c.id === fromCrypto)?.current_price * conversionRates[toCurrency])}
          </p>
        </div>
      )}
      
      <div className="mt-4 text-xs text-gray-500 dark:text-gray-400">
        <p>* Real-time prices from CoinGecko API and currency rates from ExchangeRate-API.</p>
        <p>* Data updates automatically every 30 seconds.</p>
        <p>* All rates are for informational purposes only.</p>
      </div>
    </div>
  );
};

export default CryptoConverter;