import React from 'react';
import CryptoDashboard from './components/CryptoDashboard';
import './App.css';

function App() {
  return (
    <div className="App">
      <CryptoDashboard />
    </div>
  );
}

export default App; 